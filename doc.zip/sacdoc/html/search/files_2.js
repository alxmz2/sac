var searchData=
[
  ['geometric_2emc',['geometric.mc',['../geometric_8mc.html',1,'']]]
];
