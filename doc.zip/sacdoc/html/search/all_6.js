var searchData=
[
  ['geometric_2emc',['geometric.mc',['../geometric_8mc.html',1,'']]],
  ['grad',['grad',['../diffalg_8mc.html#aca6a62cf5607f78db7882976febaa9ab',1,'diffalg.mc']]],
  ['general_20hierarchy_20diagram',['General hierarchy diagram',['../jerarquia.html',1,'']]]
];
