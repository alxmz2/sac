var searchData=
[
  ['analysis_20and_20control_20routines',['Analysis and control routines',['../ayc.html',1,'']]]
];
