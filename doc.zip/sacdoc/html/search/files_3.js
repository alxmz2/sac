var searchData=
[
  ['ncalg_2emc',['ncalg.mc',['../ncalg_8mc.html',1,'']]]
];
