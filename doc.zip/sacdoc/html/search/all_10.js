var searchData=
[
  ['todo_20list',['Todo List',['../todo.html',1,'']]],
  ['tshift',['tshift',['../operators_8mc.html#ad4fa2ce99e996c5f0acf2fee0bab4c14',1,'operators.mc']]]
];
