var searchData=
[
  ['coefpow',['coefpow',['../ncalg_8mc.html#a349fa55ad341f5bfd1e0de15c6b12cc5',1,'ncalg.mc']]]
];
