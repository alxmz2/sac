var indexSectionsWithContent =
{
  0: "_acdefghilmnoprstu",
  1: "adgnos",
  2: "_cdefghilmnprstu",
  3: "agst"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Pages"
};

